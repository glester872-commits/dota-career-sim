# Dota 2 Career Simulator

Simulador de carrera profesional de Dota 2: de los pubs a The International, o a
ninguna parte. Contratos, temporadas, mercado de fichajes, torneos, finanzas,
lesiones, retiro y sala de trofeos.

Juega aquí: **https://TU-USUARIO.github.io/TU-REPO/**

## Cómo está montado

Un solo archivo: `index.html`. Sin build, sin dependencias, sin servidor.
Todo — motor de simulación, datos, interfaz y estilos — va dentro. La partida se
guarda en el `localStorage` del navegador.

La única petición externa son las banderas de los países
(`flagcdn.com`); sin conexión el juego funciona igual, solo se quedan sin
bandera.

## Publicar en GitHub Pages

1. Sube este directorio al repositorio.
2. Ajustes → Pages → Source: **Deploy from a branch**.
3. Branch: `main`, carpeta: **`/docs`**. Guardar.
4. En un minuto la URL está viva.

`.nojekyll` está para que Pages sirva el archivo tal cual, sin pasarlo por Jekyll.

## Local

No hace falta servidor: doble clic en `index.html`. Si prefieres servirlo:

```bash
python3 -m http.server 8000
```

## Navegadores

Chrome, Edge, Firefox y Safari recientes, escritorio y móvil. El diseño baja
hasta 320 px de ancho.
